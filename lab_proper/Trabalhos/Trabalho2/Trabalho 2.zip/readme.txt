Implementou-se tudo que foi pedido no enunciado!
- A matriz é alocada dinâmicamente;
- O usuário define o conteúdo da matriz;
- O usuário deve fornecer um conteúdo compatível com o tamanho da matriz;
- A matriz é impressa na tela;
- O usuário pode buscar uma palavra de tamanho compatível com a matriz;
- Caso encontrar a palavra buscada, as coordenadas da mesma são impressas na tela;
- Caso haja mais de uma ocorrência da palavra por direção, é mostrada apenas a primeira ocorrência.