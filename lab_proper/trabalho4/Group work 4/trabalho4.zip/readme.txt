Trabalho 4 da disciplina de Laboratório de Programação 2

Implementaram-se todas as funções pedidas, que estão dispostas e acessíveis no menu principal do programa.

Observações:
- Expandiu-se um pouco o sistema de pratos em relação ao que foi originalmente pedido;
- Agora, esse se assemelha mais a um restaurante real;
- Todas as mesas começam com 4 pratos limpos. Após o termino da refeição, os pratos que lá ainda estavam estarão sujos;
- Para recolhê-los, deve-se usar a função "Recolher e lavar pratos", a qual os retira de uma mesa específica e os adiciona à pilha de pratos limpos;
- Depois, tendo pratos na pilha, pode-se arrumar a mesa novamente usando a função "Arrumar mesa".

- Foram feitas também funções que graficamente representam as mesas e a pilha de pratos com ASCII;
- Recomenda-se usá-las com um número menor de mesas (menor ou igual a 5x5), devido às limitações de espaço no terminal;
- Tamanhos maiores funcionarão, mas podem ficar desformatados.