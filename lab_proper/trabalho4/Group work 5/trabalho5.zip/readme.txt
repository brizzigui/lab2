Trabalho 5 de Laboratório de Programação 2

Foram implementadas todas as funcionalidades pedidas na especificação:

- Inserção e exclusão de cursos na árvore;
- Inserção e exclusão de alunos nas listas dos cursos;
- Impressões variadas dessas informações.