Correção da questão #03 do Trabalho 1 de Estruturas de Dados

- Refez-se toda a questão implementando listas na solução;
- Agora, criam-se nós da lista apenas para as células da matriz que violam a condição de identidade;
- Essa funcionalidade otimiza a utilização de memória, sobretudo em matrizes maiores.
